-- Zion Shores Booking App - Database Schema
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- PROFILES (extends Supabase auth.users)
-- ============================================
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('owner', 'renter', 'local')),
  verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'approved', 'rejected')),
  id_document_url TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  zip_code TEXT,
  property_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================
-- SESSIONS (time slots for each wave)
-- ============================================
CREATE TABLE sessions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  wave_id TEXT NOT NULL CHECK (wave_id IN ('perfectswell', 'dynamic', 'standing')),
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  max_capacity INTEGER NOT NULL,
  booked_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'full', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(wave_id, date, start_time)
);

-- ============================================
-- BOOKINGS
-- ============================================
CREATE TABLE bookings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  session_id UUID REFERENCES sessions(id) ON DELETE CASCADE NOT NULL,
  wave_id TEXT NOT NULL CHECK (wave_id IN ('perfectswell', 'dynamic', 'standing')),
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  amount_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'usd',
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'refunded', 'failed')),
  stripe_payment_intent_id TEXT,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'cancelled', 'completed', 'no_show')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================
-- WAVE CONDITIONS (real-time wave status)
-- ============================================
CREATE TABLE wave_conditions (
  wave_id TEXT PRIMARY KEY CHECK (wave_id IN ('perfectswell', 'dynamic', 'standing')),
  current_height_ft DECIMAL(3,1) NOT NULL DEFAULT 0,
  water_temp_f INTEGER NOT NULL DEFAULT 78,
  crowd_level TEXT NOT NULL DEFAULT 'empty' CHECK (crowd_level IN ('empty', 'light', 'moderate', 'busy', 'full')),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'maintenance')),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================
-- SEED: Default wave conditions
-- ============================================
INSERT INTO wave_conditions (wave_id, current_height_ft, water_temp_f, crowd_level, status) VALUES
  ('perfectswell', 5.0, 78, 'moderate', 'open'),
  ('dynamic', 3.0, 78, 'light', 'open'),
  ('standing', 2.0, 80, 'empty', 'open');

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

-- Profiles: users can read their own profile, admins can read all
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Sessions: everyone can read, only system can write
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view sessions"
  ON sessions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage sessions"
  ON sessions FOR ALL
  TO authenticated
  USING (true);

-- Bookings: users can manage their own bookings
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookings"
  ON bookings FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings"
  ON bookings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bookings"
  ON bookings FOR UPDATE
  USING (auth.uid() = user_id);

-- Wave conditions: everyone can read
ALTER TABLE wave_conditions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view conditions"
  ON wave_conditions FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX idx_sessions_wave_date ON sessions(wave_id, date);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_session ON bookings(session_id);
CREATE INDEX idx_bookings_date ON bookings(date);
CREATE INDEX idx_profiles_role ON profiles(role);

-- ============================================
-- STORAGE BUCKET for ID documents
-- ============================================
INSERT INTO storage.buckets (id, name, public) VALUES ('id-documents', 'id-documents', false);

CREATE POLICY "Users can upload own ID docs"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'id-documents' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can view own ID docs"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'id-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
