export type UserRole = 'owner' | 'renter' | 'local';

export type VerificationStatus = 'pending' | 'approved' | 'rejected';

export interface User {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  role: UserRole;
  verification_status: VerificationStatus;
  id_document_url?: string;
  address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  property_id?: string; // for owners/renters
  created_at: string;
  updated_at: string;
}

export type WaveId = 'perfectswell' | 'dynamic' | 'standing';

export type WaveSkillLevel = 'advanced' | 'intermediate' | 'beginner';

export interface Wave {
  id: WaveId;
  name: string;
  subtitle: string;
  description: string;
  skill_level: WaveSkillLevel;
  max_capacity: number;
  width_ft: number;
  wave_height_range: string;
  image_key: string;
  features: string[];
}

export interface WaveConditions {
  wave_id: WaveId;
  current_height_ft: number;
  water_temp_f: number;
  crowd_level: 'empty' | 'light' | 'moderate' | 'busy' | 'full';
  status: 'open' | 'closed' | 'maintenance';
  updated_at: string;
}

export interface Session {
  id: string;
  wave_id: WaveId;
  date: string; // YYYY-MM-DD
  start_time: string; // HH:MM
  end_time: string; // HH:MM
  max_capacity: number;
  booked_count: number;
  status: 'available' | 'full' | 'cancelled';
}

export interface Booking {
  id: string;
  user_id: string;
  session_id: string;
  wave_id: WaveId;
  date: string;
  start_time: string;
  end_time: string;
  amount_cents: number;
  currency: string;
  payment_status: 'pending' | 'paid' | 'refunded' | 'failed';
  stripe_payment_intent_id?: string;
  status: 'confirmed' | 'cancelled' | 'completed' | 'no_show';
  created_at: string;
}

export interface PricingTier {
  wave_id: WaveId;
  role: UserRole;
  price_cents: number;
  label: string;
}

export interface BookingWindow {
  role: UserRole;
  days_ahead: number;
  label: string;
}
