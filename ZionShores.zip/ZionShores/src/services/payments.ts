import { supabase } from './supabase';

const STRIPE_API_URL = process.env.EXPO_PUBLIC_API_URL || 'https://your-api.com';

export async function createPaymentIntent(
  bookingId: string,
  amountCents: number
): Promise<{ clientSecret: string | null; error: string | null }> {
  try {
    // In production, this calls your backend which creates the Stripe PaymentIntent
    const { data: { session } } = await supabase.auth.getSession();

    const response = await fetch(`${STRIPE_API_URL}/api/create-payment-intent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session?.access_token}`,
      },
      body: JSON.stringify({
        booking_id: bookingId,
        amount: amountCents,
        currency: 'usd',
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { clientSecret: null, error: data.error || 'Payment creation failed' };
    }

    return { clientSecret: data.client_secret, error: null };
  } catch (err: any) {
    return { clientSecret: null, error: err.message || 'Network error' };
  }
}

export async function confirmBookingPayment(
  bookingId: string,
  paymentIntentId: string
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('bookings')
    .update({
      payment_status: 'paid',
      stripe_payment_intent_id: paymentIntentId,
    })
    .eq('id', bookingId);

  return { error: error?.message || null };
}

export async function refundBooking(
  bookingId: string
): Promise<{ error: string | null }> {
  try {
    const { data: { session } } = await supabase.auth.getSession();

    const response = await fetch(`${STRIPE_API_URL}/api/refund`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session?.access_token}`,
      },
      body: JSON.stringify({ booking_id: bookingId }),
    });

    if (!response.ok) {
      const data = await response.json();
      return { error: data.error || 'Refund failed' };
    }

    await supabase
      .from('bookings')
      .update({ payment_status: 'refunded', status: 'cancelled' })
      .eq('id', bookingId);

    return { error: null };
  } catch (err: any) {
    return { error: err.message || 'Network error' };
  }
}
