import { supabase } from './supabase';
import { WaveConditions, WaveId } from '../types';
import { DEFAULT_CONDITIONS } from '../constants/waves';

export async function getWaveConditions(): Promise<{
  conditions: WaveConditions[];
  error: string | null;
}> {
  const { data, error } = await supabase
    .from('wave_conditions')
    .select('*')
    .order('wave_id');

  if (error || !data || data.length === 0) {
    return { conditions: DEFAULT_CONDITIONS, error: null };
  }

  return { conditions: data as WaveConditions[], error: null };
}

export async function getConditionsForWave(
  waveId: WaveId
): Promise<{ conditions: WaveConditions | null; error: string | null }> {
  const { data, error } = await supabase
    .from('wave_conditions')
    .select('*')
    .eq('wave_id', waveId)
    .single();

  if (error || !data) {
    const fallback = DEFAULT_CONDITIONS.find((c) => c.wave_id === waveId) || null;
    return { conditions: fallback, error: null };
  }

  return { conditions: data as WaveConditions, error: null };
}

export function getCrowdColor(level: string): string {
  switch (level) {
    case 'empty':
      return '#2EC4B6';
    case 'light':
      return '#87CEEB';
    case 'moderate':
      return '#F4A261';
    case 'busy':
      return '#E76F51';
    case 'full':
      return '#DC2626';
    default:
      return '#A0B4C8';
  }
}

export function formatTemp(tempF: number): string {
  return `${tempF}°F`;
}

export function formatHeight(heightFt: number): string {
  return `${heightFt} ft`;
}
