import { supabase } from './supabase';
import { Booking, Session, UserRole, WaveId } from '../types';
import { getBookingWindow, getPrice, SESSION_HOURS, WAVES } from '../constants/waves';
import { addDays, format, startOfDay, isBefore, isAfter, parseISO } from 'date-fns';

export function getMaxBookingDate(role: UserRole): Date {
  const window = getBookingWindow(role);
  if (!window) return new Date();
  return addDays(startOfDay(new Date()), window.days_ahead);
}

export function canBookDate(role: UserRole, date: Date): boolean {
  const today = startOfDay(new Date());
  const maxDate = getMaxBookingDate(role);
  return !isBefore(date, today) && !isAfter(date, maxDate);
}

export function generateSessionsForDay(waveId: WaveId, date: string): Omit<Session, 'id'>[] {
  const wave = WAVES.find((w) => w.id === waveId);
  if (!wave) return [];

  const sessions: Omit<Session, 'id'>[] = [];
  for (let hour = SESSION_HOURS.start; hour < SESSION_HOURS.end; hour++) {
    const startTime = `${hour.toString().padStart(2, '0')}:00`;
    const endTime = `${(hour + 1).toString().padStart(2, '0')}:00`;
    sessions.push({
      wave_id: waveId,
      date,
      start_time: startTime,
      end_time: endTime,
      max_capacity: wave.max_capacity,
      booked_count: 0,
      status: 'available',
    });
  }
  return sessions;
}

export async function getSessionsForDate(
  waveId: WaveId,
  date: string
): Promise<{ sessions: Session[]; error: string | null }> {
  const { data, error } = await supabase
    .from('sessions')
    .select('*')
    .eq('wave_id', waveId)
    .eq('date', date)
    .order('start_time', { ascending: true });

  if (error) return { sessions: [], error: error.message };

  if (!data || data.length === 0) {
    const templates = generateSessionsForDay(waveId, date);
    const { data: created, error: createError } = await supabase
      .from('sessions')
      .insert(templates)
      .select();

    if (createError) return { sessions: [], error: createError.message };
    return { sessions: (created as Session[]) || [], error: null };
  }

  return { sessions: data as Session[], error: null };
}

export async function createBooking(
  userId: string,
  sessionId: string,
  waveId: WaveId,
  role: UserRole,
  date: string,
  startTime: string,
  endTime: string
): Promise<{ booking: Booking | null; error: string | null }> {
  const pricing = getPrice(waveId, role);
  if (!pricing) return { booking: null, error: 'Pricing not found for this wave and role' };

  // Check session availability
  const { data: session } = await supabase
    .from('sessions')
    .select('*')
    .eq('id', sessionId)
    .single();

  if (!session) return { booking: null, error: 'Session not found' };
  if (session.booked_count >= session.max_capacity) {
    return { booking: null, error: 'Session is full' };
  }

  // Check duplicate booking
  const { data: existing } = await supabase
    .from('bookings')
    .select('id')
    .eq('user_id', userId)
    .eq('session_id', sessionId)
    .eq('status', 'confirmed')
    .single();

  if (existing) return { booking: null, error: 'You already have a booking for this session' };

  // Create booking
  const { data: booking, error } = await supabase
    .from('bookings')
    .insert({
      user_id: userId,
      session_id: sessionId,
      wave_id: waveId,
      date,
      start_time: startTime,
      end_time: endTime,
      amount_cents: pricing.price_cents,
      currency: 'usd',
      payment_status: 'pending',
      status: 'confirmed',
    })
    .select()
    .single();

  if (error) return { booking: null, error: error.message };

  // Increment booked count
  await supabase
    .from('sessions')
    .update({ booked_count: session.booked_count + 1 })
    .eq('id', sessionId);

  return { booking: booking as Booking, error: null };
}

export async function getUserBookings(
  userId: string
): Promise<{ bookings: Booking[]; error: string | null }> {
  const { data, error } = await supabase
    .from('bookings')
    .select('*')
    .eq('user_id', userId)
    .order('date', { ascending: false });

  if (error) return { bookings: [], error: error.message };
  return { bookings: (data as Booking[]) || [], error: null };
}

export async function cancelBooking(
  bookingId: string
): Promise<{ error: string | null }> {
  const { data: booking } = await supabase
    .from('bookings')
    .select('*')
    .eq('id', bookingId)
    .single();

  if (!booking) return { error: 'Booking not found' };

  const { error } = await supabase
    .from('bookings')
    .update({ status: 'cancelled' })
    .eq('id', bookingId);

  if (error) return { error: error.message };

  // Decrement session count
  await supabase
    .from('sessions')
    .update({ booked_count: Math.max(0, (booking as any).booked_count - 1) })
    .eq('id', booking.session_id);

  return { error: null };
}

export async function getUpcomingBookings(
  userId: string
): Promise<{ bookings: Booking[]; error: string | null }> {
  const today = format(new Date(), 'yyyy-MM-dd');
  const { data, error } = await supabase
    .from('bookings')
    .select('*')
    .eq('user_id', userId)
    .eq('status', 'confirmed')
    .gte('date', today)
    .order('date', { ascending: true })
    .order('start_time', { ascending: true });

  if (error) return { bookings: [], error: error.message };
  return { bookings: (data as Booking[]) || [], error: null };
}
