import { supabase } from './supabase';
import { User, UserRole } from '../types';

export async function signUp(
  email: string,
  password: string,
  fullName: string,
  role: UserRole
): Promise<{ user: User | null; error: string | null }> {
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName, role },
    },
  });

  if (authError) return { user: null, error: authError.message };
  if (!authData.user) return { user: null, error: 'Signup failed' };

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .insert({
      id: authData.user.id,
      email,
      full_name: fullName,
      role,
      verification_status: role === 'local' ? 'pending' : 'approved',
    })
    .select()
    .single();

  if (profileError) return { user: null, error: profileError.message };

  return { user: profile as User, error: null };
}

export async function signIn(
  email: string,
  password: string
): Promise<{ user: User | null; error: string | null }> {
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (authError) return { user: null, error: authError.message };
  if (!authData.user) return { user: null, error: 'Login failed' };

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', authData.user.id)
    .single();

  if (profileError) return { user: null, error: profileError.message };

  return { user: profile as User, error: null };
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

export async function getCurrentUser(): Promise<User | null> {
  const {
    data: { user: authUser },
  } = await supabase.auth.getUser();

  if (!authUser) return null;

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', authUser.id)
    .single();

  return profile as User | null;
}

export async function updateProfile(
  userId: string,
  updates: Partial<User>
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId);

  return { error: error?.message || null };
}

export async function uploadIdDocument(
  userId: string,
  uri: string
): Promise<{ url: string | null; error: string | null }> {
  const fileName = `${userId}/id-document-${Date.now()}.jpg`;

  const response = await fetch(uri);
  const blob = await response.blob();

  const { error: uploadError } = await supabase.storage
    .from('id-documents')
    .upload(fileName, blob, { contentType: 'image/jpeg' });

  if (uploadError) return { url: null, error: uploadError.message };

  const {
    data: { publicUrl },
  } = supabase.storage.from('id-documents').getPublicUrl(fileName);

  await supabase
    .from('profiles')
    .update({ id_document_url: publicUrl })
    .eq('id', userId);

  return { url: publicUrl, error: null };
}
