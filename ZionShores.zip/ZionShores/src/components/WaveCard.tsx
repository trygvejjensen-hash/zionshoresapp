import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Wave, WaveConditions, UserRole } from '../types';
import { colors, borderRadius, spacing, shadows } from '../constants/theme';
import { gradients } from '../constants/theme';
import { getPrice } from '../constants/waves';
import { getCrowdColor, formatTemp, formatHeight } from '../services/conditions';

const { width } = Dimensions.get('window');

interface Props {
  wave: Wave;
  conditions?: WaveConditions;
  userRole?: UserRole;
  onPress: () => void;
}

const SKILL_CONFIG = {
  beginner: { color: colors.beginner, icon: 'water-outline' as const, label: 'Beginner' },
  intermediate: { color: colors.intermediate, icon: 'trending-up' as const, label: 'Intermediate' },
  advanced: { color: colors.advanced, icon: 'flame' as const, label: 'Advanced' },
};

const GRADIENT_MAP: Record<string, string[]> = {
  perfectswell: gradients.perfectswell,
  dynamic: gradients.dynamic,
  standing: gradients.standing,
};

export function WaveCard({ wave, conditions, userRole, onPress }: Props) {
  const skill = SKILL_CONFIG[wave.skill_level];
  const price = userRole ? getPrice(wave.id, userRole) : null;
  const gradient = GRADIENT_MAP[wave.id] || gradients.card;

  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.85}>
      <LinearGradient
        colors={gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gradient}
      >
        <View style={styles.overlay}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.titleRow}>
              <Text style={styles.name}>{wave.name}</Text>
              <View style={[styles.skillBadge, { backgroundColor: skill.color + '30' }]}>
                <Ionicons name={skill.icon} size={12} color={skill.color} />
                <Text style={[styles.skillText, { color: skill.color }]}>{skill.label}</Text>
              </View>
            </View>
            <Text style={styles.subtitle}>{wave.subtitle}</Text>
          </View>

          {/* Conditions */}
          {conditions && (
            <View style={styles.conditionsRow}>
              <View style={styles.conditionItem}>
                <Ionicons name="resize-outline" size={16} color={colors.oceanLight} />
                <Text style={styles.conditionValue}>
                  {formatHeight(conditions.current_height_ft)}
                </Text>
              </View>
              <View style={styles.conditionItem}>
                <Ionicons name="thermometer-outline" size={16} color={colors.warning} />
                <Text style={styles.conditionValue}>
                  {formatTemp(conditions.water_temp_f)}
                </Text>
              </View>
              <View style={styles.conditionItem}>
                <Ionicons name="people-outline" size={16} color={getCrowdColor(conditions.crowd_level)} />
                <Text
                  style={[
                    styles.conditionValue,
                    { color: getCrowdColor(conditions.crowd_level) },
                  ]}
                >
                  {conditions.crowd_level}
                </Text>
              </View>
              <View
                style={[
                  styles.statusDot,
                  {
                    backgroundColor:
                      conditions.status === 'open' ? colors.success : colors.error,
                  },
                ]}
              />
            </View>
          )}

          {/* Footer */}
          <View style={styles.footer}>
            <View style={styles.specs}>
              <Text style={styles.specText}>{wave.width_ft}ft wide</Text>
              <Text style={styles.specDot}>·</Text>
              <Text style={styles.specText}>{wave.wave_height_range}</Text>
              <Text style={styles.specDot}>·</Text>
              <Text style={styles.specText}>Max {wave.max_capacity}</Text>
            </View>
            {price && (
              <View style={styles.priceTag}>
                <Text style={styles.priceText}>{price.label}/hr</Text>
              </View>
            )}
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: borderRadius.lg,
    overflow: 'hidden',
    ...shadows.large,
  },
  gradient: {
    minHeight: 180,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 25, 35, 0.55)',
    padding: spacing.lg,
    justifyContent: 'space-between',
  },
  header: {},
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.white,
    flex: 1,
  },
  skillBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    gap: 4,
  },
  skillText: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    fontWeight: '400',
  },
  conditionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  conditionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  conditionValue: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 'auto',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.md,
  },
  specs: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  specText: {
    fontSize: 12,
    color: colors.textMuted,
  },
  specDot: {
    fontSize: 12,
    color: colors.textMuted,
    marginHorizontal: spacing.xs,
  },
  priceTag: {
    backgroundColor: colors.sand + '25',
    paddingHorizontal: spacing.sm + 4,
    paddingVertical: spacing.xs + 2,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.sand + '40',
  },
  priceText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.sand,
  },
});
