import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface Props {
  colors?: string[];
  style?: ViewStyle;
  children: React.ReactNode;
}

export function GradientBackground({
  colors = ['#0F1923', '#1A2733', '#164B60'],
  style,
  children,
}: Props) {
  return (
    <LinearGradient colors={colors} style={[styles.container, style]}>
      {children}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
