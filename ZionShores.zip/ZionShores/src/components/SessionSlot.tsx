import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Session } from '../types';
import { colors, borderRadius, spacing } from '../constants/theme';

interface Props {
  session: Session;
  selected: boolean;
  onPress: () => void;
}

export function SessionSlot({ session, selected, onPress }: Props) {
  const isFull = session.booked_count >= session.max_capacity;
  const isCancelled = session.status === 'cancelled';
  const isDisabled = isFull || isCancelled;
  const spotsLeft = session.max_capacity - session.booked_count;

  const formatTime = (time: string) => {
    const [h] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const display = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${display}:00 ${ampm}`;
  };

  return (
    <TouchableOpacity
      style={[
        styles.container,
        selected && styles.selected,
        isDisabled && styles.disabled,
      ]}
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={0.7}
    >
      <View style={styles.timeRow}>
        <Ionicons
          name="time-outline"
          size={16}
          color={selected ? colors.white : isDisabled ? colors.textMuted : colors.sand}
        />
        <Text style={[styles.time, selected && styles.selectedText, isDisabled && styles.disabledText]}>
          {formatTime(session.start_time)} – {formatTime(session.end_time)}
        </Text>
      </View>
      <View style={styles.statusRow}>
        {isCancelled ? (
          <Text style={styles.cancelledText}>Cancelled</Text>
        ) : isFull ? (
          <Text style={styles.fullText}>Full</Text>
        ) : (
          <>
            <View style={styles.capacityBar}>
              <View
                style={[
                  styles.capacityFill,
                  {
                    width: `${(session.booked_count / session.max_capacity) * 100}%`,
                    backgroundColor:
                      spotsLeft <= 3 ? colors.warning : selected ? colors.white : colors.teal,
                  },
                ]}
              />
            </View>
            <Text
              style={[
                styles.spots,
                selected && styles.selectedText,
                spotsLeft <= 3 && styles.lowSpots,
              ]}
            >
              {spotsLeft} spot{spotsLeft !== 1 ? 's' : ''} left
            </Text>
          </>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  selected: {
    backgroundColor: colors.sand,
    borderColor: colors.sandLight,
  },
  disabled: {
    backgroundColor: colors.card,
    opacity: 0.5,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  time: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  selectedText: {
    color: colors.background,
  },
  disabledText: {
    color: colors.textMuted,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  capacityBar: {
    flex: 1,
    height: 4,
    backgroundColor: colors.surface,
    borderRadius: 2,
    overflow: 'hidden',
  },
  capacityFill: {
    height: '100%',
    borderRadius: 2,
  },
  spots: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.textSecondary,
    minWidth: 80,
    textAlign: 'right',
  },
  lowSpots: {
    color: colors.warning,
  },
  fullText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.error,
  },
  cancelledText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
  },
});
