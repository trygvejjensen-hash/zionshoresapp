import { Wave, PricingTier, BookingWindow, WaveConditions } from '../types';

export const WAVES: Wave[] = [
  {
    id: 'perfectswell',
    name: 'PerfectSwell Zion',
    subtitle: 'World-Class Traveling Wave',
    description:
      'The largest PerfectSwell® surf pool in the world. Gen 6 air-pressure technology replicates point break, beach break, and reef break surf for an authentic ocean experience.',
    skill_level: 'advanced',
    max_capacity: 20,
    width_ft: 200,
    wave_height_range: '3-8 ft',
    image_key: 'perfectswell',
    features: [
      'Infinite wave variety',
      'Point, beach & reef breaks',
      'Gen 6 technology',
      'Automated water temp control',
      'World-class competition ready',
    ],
  },
  {
    id: 'dynamic',
    name: 'UNIT Dynamic Wave',
    subtitle: 'Progressive Moving Wave',
    description:
      "The world's first 164-foot wide dynamic wave system. Patent-pending programmable water flow creates multiple moving wave pockets with 20-second rides.",
    skill_level: 'intermediate',
    max_capacity: 16,
    width_ft: 164,
    wave_height_range: '2-5 ft',
    image_key: 'dynamic',
    features: [
      'Multiple wave pockets',
      '20-second rides',
      'Programmable flow control',
      'Bridge to advanced surfing',
      'Adjustable height & speed',
    ],
  },
  {
    id: 'standing',
    name: 'UNIT Standing Wave',
    subtitle: 'Beginner-Friendly Training Wave',
    description:
      'A controlled standing wave with adjustable 1-6 ft face height. Perfect for first-time surfers and advanced riders working on new tricks. Maximum repetition in minimum time.',
    skill_level: 'beginner',
    max_capacity: 12,
    width_ft: 60,
    wave_height_range: '1-6 ft',
    image_key: 'standing',
    features: [
      'Adjustable 1-6 ft face',
      'Beginner friendly',
      'High repetition sessions',
      'Technical progression',
      'Controlled environment',
    ],
  },
];

export const PRICING: PricingTier[] = [
  // PerfectSwell pricing
  { wave_id: 'perfectswell', role: 'owner', price_cents: 10000, label: '$100' },
  { wave_id: 'perfectswell', role: 'renter', price_cents: 20000, label: '$200' },
  { wave_id: 'perfectswell', role: 'local', price_cents: 20000, label: '$200' },
  // Dynamic pricing
  { wave_id: 'dynamic', role: 'owner', price_cents: 5000, label: '$50' },
  { wave_id: 'dynamic', role: 'renter', price_cents: 5000, label: '$50' },
  { wave_id: 'dynamic', role: 'local', price_cents: 5000, label: '$50' },
  // Standing pricing
  { wave_id: 'standing', role: 'owner', price_cents: 5000, label: '$50' },
  { wave_id: 'standing', role: 'renter', price_cents: 5000, label: '$50' },
  { wave_id: 'standing', role: 'local', price_cents: 5000, label: '$50' },
];

export const BOOKING_WINDOWS: BookingWindow[] = [
  { role: 'owner', days_ahead: 30, label: '1 month ahead' },
  { role: 'renter', days_ahead: 7, label: '1 week ahead' },
  { role: 'local', days_ahead: 1, label: '1 day ahead' },
];

export const SESSION_HOURS = {
  start: 7, // 7 AM
  end: 12, // 12 PM (noon)
  duration_minutes: 60,
};

export const SESSIONS_PER_DAY = SESSION_HOURS.end - SESSION_HOURS.start; // 5 sessions

export const DEFAULT_CONDITIONS: WaveConditions[] = [
  {
    wave_id: 'perfectswell',
    current_height_ft: 5,
    water_temp_f: 78,
    crowd_level: 'moderate',
    status: 'open',
    updated_at: new Date().toISOString(),
  },
  {
    wave_id: 'dynamic',
    current_height_ft: 3,
    water_temp_f: 78,
    crowd_level: 'light',
    status: 'open',
    updated_at: new Date().toISOString(),
  },
  {
    wave_id: 'standing',
    current_height_ft: 2,
    water_temp_f: 80,
    crowd_level: 'empty',
    status: 'open',
    updated_at: new Date().toISOString(),
  },
];

export function getPrice(waveId: string, role: string): PricingTier | undefined {
  return PRICING.find((p) => p.wave_id === waveId && p.role === role);
}

export function getBookingWindow(role: string): BookingWindow | undefined {
  return BOOKING_WINDOWS.find((w) => w.role === role);
}

export function getWave(waveId: string): Wave | undefined {
  return WAVES.find((w) => w.id === waveId);
}
