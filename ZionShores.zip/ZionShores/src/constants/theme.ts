export const colors = {
  // Desert luxury palette
  sand: '#D4A574',
  sandLight: '#E8D5B7',
  sandstone: '#C4956A',
  terracotta: '#B85C38',
  desert: '#8B6F47',
  warmBrown: '#6B4226',

  // Ocean surf palette
  ocean: '#1B6B93',
  oceanDeep: '#164B60',
  oceanLight: '#4FC0D0',
  teal: '#2EC4B6',
  seafoam: '#A3D9D3',
  skyBlue: '#87CEEB',

  // Core UI
  background: '#0F1923',
  backgroundLight: '#1A2733',
  card: '#1E3044',
  cardLight: '#253D54',
  surface: '#2A4560',

  // Text
  textPrimary: '#F5F0EB',
  textSecondary: '#A0B4C8',
  textMuted: '#6B8299',
  textAccent: '#D4A574',

  // Status
  success: '#2EC4B6',
  warning: '#F4A261',
  error: '#E76F51',
  info: '#4FC0D0',

  // Skill level badges
  beginner: '#2EC4B6',
  intermediate: '#F4A261',
  advanced: '#E76F51',

  // Misc
  white: '#FFFFFF',
  black: '#000000',
  overlay: 'rgba(15, 25, 35, 0.85)',
  divider: 'rgba(160, 180, 200, 0.15)',
};

export const gradients = {
  header: ['#164B60', '#1B6B93', '#1A2733'],
  card: ['#1E3044', '#253D54'],
  perfectswell: ['#E76F51', '#D4A574', '#1B6B93'],
  dynamic: ['#F4A261', '#D4A574', '#2EC4B6'],
  standing: ['#2EC4B6', '#4FC0D0', '#87CEEB'],
  button: ['#D4A574', '#C4956A'],
  buttonSecondary: ['#1B6B93', '#164B60'],
};

export const fonts = {
  regular: 'System',
  medium: 'System',
  semibold: 'System',
  bold: 'System',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const shadows = {
  small: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
};
