import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { GradientBackground } from '../components/GradientBackground';
import { Button } from '../components/Button';
import { useAuth } from '../hooks/useAuth';
import { uploadIdDocument } from '../services/auth';
import { colors, spacing, borderRadius, shadows } from '../constants/theme';
import { getBookingWindow } from '../constants/waves';

export function ProfileScreen({ navigation }: any) {
  const { user, signOut, refreshUser } = useAuth();
  const [uploadLoading, setUploadLoading] = useState(false);

  if (!user) return null;

  const bookingWindow = getBookingWindow(user.role);

  const ROLE_CONFIG: Record<string, { label: string; icon: string; color: string }> = {
    owner: { label: 'Property Owner', icon: 'home', color: colors.sand },
    renter: { label: 'Property Renter', icon: 'key', color: colors.oceanLight },
    local: { label: 'Washington, UT Local', icon: 'location', color: colors.teal },
  };

  const roleConfig = ROLE_CONFIG[user.role];

  const VERIFICATION_CONFIG: Record<string, { label: string; color: string; icon: string }> = {
    approved: { label: 'Verified', color: colors.success, icon: 'checkmark-circle' },
    pending: { label: 'Pending Review', color: colors.warning, icon: 'hourglass' },
    rejected: { label: 'Rejected', color: colors.error, icon: 'close-circle' },
  };
  const verificationConfig = VERIFICATION_CONFIG[user.verification_status];

  async function handleUploadId() {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Permission Required', 'Please grant photo library access to upload your ID.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });

    if (result.canceled) return;

    setUploadLoading(true);
    const uploadResult = await uploadIdDocument(user.id, result.assets[0].uri);
    setUploadLoading(false);

    if (uploadResult.error) {
      Alert.alert('Upload Error', uploadResult.error);
    } else {
      Alert.alert('Success', 'Your ID has been uploaded and is pending review.');
      refreshUser();
    }
  }

  function handleSignOut() {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: signOut },
    ]);
  }

  return (
    <GradientBackground>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <Text style={styles.title}>Profile</Text>

        {/* Profile Card */}
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user.full_name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase()}
            </Text>
          </View>
          <Text style={styles.name}>{user.full_name}</Text>
          <Text style={styles.email}>{user.email}</Text>

          <View style={styles.badgesRow}>
            <View style={[styles.badge, { backgroundColor: roleConfig.color + '20' }]}>
              <Ionicons name={roleConfig.icon as any} size={14} color={roleConfig.color} />
              <Text style={[styles.badgeText, { color: roleConfig.color }]}>
                {roleConfig.label}
              </Text>
            </View>
            <View
              style={[styles.badge, { backgroundColor: verificationConfig.color + '20' }]}
            >
              <Ionicons
                name={verificationConfig.icon as any}
                size={14}
                color={verificationConfig.color}
              />
              <Text style={[styles.badgeText, { color: verificationConfig.color }]}>
                {verificationConfig.label}
              </Text>
            </View>
          </View>
        </View>

        {/* Booking Access Info */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Your Booking Access</Text>
          <View style={styles.infoRow}>
            <Ionicons name="calendar-outline" size={18} color={colors.sand} />
            <Text style={styles.infoText}>
              Book sessions up to{' '}
              <Text style={styles.infoBold}>{bookingWindow?.label}</Text>
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Ionicons name="trophy-outline" size={18} color={colors.sand} />
            <Text style={styles.infoText}>
              Priority level:{' '}
              <Text style={styles.infoBold}>
                {user.role === 'owner' ? '1 (Highest)' : user.role === 'renter' ? '2' : '3'}
              </Text>
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Ionicons name="cash-outline" size={18} color={colors.sand} />
            <Text style={styles.infoText}>
              PerfectSwell rate:{' '}
              <Text style={styles.infoBold}>
                {user.role === 'owner' ? '$100/hr' : '$200/hr'}
              </Text>
            </Text>
          </View>
        </View>

        {/* ID Upload (for locals) */}
        {user.role === 'local' && (
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Residency Verification</Text>
            {user.id_document_url ? (
              <View style={styles.infoRow}>
                <Ionicons name="document-text" size={18} color={colors.success} />
                <Text style={styles.infoText}>
                  ID uploaded.{' '}
                  <Text style={{ color: verificationConfig.color }}>
                    {verificationConfig.label}
                  </Text>
                </Text>
              </View>
            ) : (
              <>
                <Text style={styles.uploadHint}>
                  Upload a photo of your ID showing a Washington, UT address to verify your
                  local resident status.
                </Text>
                <Button
                  title="Upload ID Document"
                  onPress={handleUploadId}
                  loading={uploadLoading}
                  variant="secondary"
                  size="medium"
                  style={styles.uploadButton}
                />
              </>
            )}
          </View>
        )}

        {/* Menu Items */}
        <View style={styles.menuSection}>
          <MenuItem
            icon="notifications-outline"
            label="Notifications"
            onPress={() => Alert.alert('Coming Soon', 'Notification settings coming soon.')}
          />
          <MenuItem
            icon="card-outline"
            label="Payment Methods"
            onPress={() => Alert.alert('Coming Soon', 'Payment management coming soon.')}
          />
          <MenuItem
            icon="help-circle-outline"
            label="Help & Support"
            onPress={() => Alert.alert('Support', 'Contact us at support@zionshores.com')}
          />
          <MenuItem
            icon="document-text-outline"
            label="Terms & Conditions"
            onPress={() => Alert.alert('Terms', 'Terms and conditions will open in browser.')}
          />
        </View>

        {/* Sign Out */}
        <Button
          title="Sign Out"
          onPress={handleSignOut}
          variant="danger"
          size="large"
          style={styles.signOutButton}
        />

        <Text style={styles.version}>Zion Shores v1.0.0</Text>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </GradientBackground>
  );
}

function MenuItem({
  icon,
  label,
  onPress,
}: {
  icon: string;
  label: string;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity style={menuStyles.container} onPress={onPress} activeOpacity={0.7}>
      <Ionicons name={icon as any} size={20} color={colors.textSecondary} />
      <Text style={menuStyles.label}>{label}</Text>
      <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
    </TouchableOpacity>
  );
}

const menuStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    gap: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  label: {
    flex: 1,
    fontSize: 15,
    color: colors.textPrimary,
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingTop: spacing.xxl + spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.lg,
  },
  profileCard: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    alignItems: 'center',
    marginBottom: spacing.md,
    ...shadows.medium,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.sand + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
    borderWidth: 2,
    borderColor: colors.sand + '40',
  },
  avatarText: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.sand,
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  badgesRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs + 1,
    borderRadius: borderRadius.full,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.md,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  infoText: {
    fontSize: 14,
    color: colors.textSecondary,
    flex: 1,
  },
  infoBold: {
    fontWeight: '700',
    color: colors.sand,
  },
  uploadHint: {
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 19,
    marginBottom: spacing.md,
  },
  uploadButton: {
    alignSelf: 'flex-start',
  },
  menuSection: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    paddingVertical: spacing.xs,
    marginBottom: spacing.lg,
  },
  signOutButton: {
    marginBottom: spacing.md,
  },
  version: {
    textAlign: 'center',
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.lg,
  },
  bottomSpacer: {
    height: spacing.xxl,
  },
});
