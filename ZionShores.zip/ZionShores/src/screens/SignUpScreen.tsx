import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GradientBackground } from '../components/GradientBackground';
import { Button } from '../components/Button';
import { useAuth } from '../hooks/useAuth';
import { colors, spacing, borderRadius } from '../constants/theme';
import { UserRole } from '../types';

const ROLES: { id: UserRole; label: string; icon: string; description: string }[] = [
  {
    id: 'owner',
    label: 'Property Owner',
    icon: 'home',
    description: 'I own a property at Zion Shores. Book up to 1 month ahead.',
  },
  {
    id: 'renter',
    label: 'Property Renter',
    icon: 'key',
    description: "I'm renting/staying at a Zion Shores property. Book up to 1 week ahead.",
  },
  {
    id: 'local',
    label: 'Washington, UT Local',
    icon: 'location',
    description: 'I live in Washington, Utah. ID verification required. Book 1 day ahead.',
  },
];

export function SignUpScreen({ navigation }: any) {
  const { signUp } = useAuth();
  const [step, setStep] = useState<'role' | 'details'>('role');
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSignUp() {
    if (!selectedRole || !fullName || !email || !password) {
      setError('Please fill in all fields');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    setError('');
    const result = await signUp(email, password, fullName, selectedRole);
    setLoading(false);
    if (result.error) {
      setError(result.error);
    }
  }

  return (
    <GradientBackground>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => (step === 'details' ? setStep('role') : navigation.goBack())}
            >
              <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
            </TouchableOpacity>
            <Text style={styles.title}>
              {step === 'role' ? 'Choose Your Access' : 'Create Account'}
            </Text>
            <Text style={styles.subtitle}>
              {step === 'role'
                ? 'Select how you connect to Zion Shores'
                : `Signing up as ${ROLES.find((r) => r.id === selectedRole)?.label}`}
            </Text>
          </View>

          {step === 'role' ? (
            // Role Selection
            <View style={styles.rolesContainer}>
              {ROLES.map((role) => (
                <TouchableOpacity
                  key={role.id}
                  style={[
                    styles.roleCard,
                    selectedRole === role.id && styles.roleCardSelected,
                  ]}
                  onPress={() => setSelectedRole(role.id)}
                  activeOpacity={0.7}
                >
                  <View style={styles.roleHeader}>
                    <View
                      style={[
                        styles.roleIcon,
                        selectedRole === role.id && styles.roleIconSelected,
                      ]}
                    >
                      <Ionicons
                        name={role.icon as any}
                        size={24}
                        color={selectedRole === role.id ? colors.background : colors.sand}
                      />
                    </View>
                    <View style={styles.roleTextContainer}>
                      <Text
                        style={[
                          styles.roleLabel,
                          selectedRole === role.id && styles.roleLabelSelected,
                        ]}
                      >
                        {role.label}
                      </Text>
                      <Text style={styles.roleDescription}>{role.description}</Text>
                    </View>
                    {selectedRole === role.id && (
                      <Ionicons name="checkmark-circle" size={24} color={colors.sand} />
                    )}
                  </View>
                </TouchableOpacity>
              ))}

              <Button
                title="Continue"
                onPress={() => setStep('details')}
                disabled={!selectedRole}
                size="large"
                style={styles.continueButton}
              />
            </View>
          ) : (
            // Account Details
            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Ionicons name="person-outline" size={20} color={colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Full name"
                  placeholderTextColor={colors.textMuted}
                  value={fullName}
                  onChangeText={setFullName}
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputContainer}>
                <Ionicons name="mail-outline" size={20} color={colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Email address"
                  placeholderTextColor={colors.textMuted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputContainer}>
                <Ionicons name="lock-closed-outline" size={20} color={colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Password (min 6 characters)"
                  placeholderTextColor={colors.textMuted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                />
              </View>

              {selectedRole === 'local' && (
                <View style={styles.verificationNote}>
                  <Ionicons name="information-circle" size={20} color={colors.info} />
                  <Text style={styles.verificationText}>
                    After signup, you'll need to upload a photo ID showing a Washington, UT address for verification.
                  </Text>
                </View>
              )}

              {error ? (
                <View style={styles.errorContainer}>
                  <Ionicons name="alert-circle" size={16} color={colors.error} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              ) : null}

              <Button
                title="Create Account"
                onPress={handleSignUp}
                loading={loading}
                size="large"
                style={styles.signUpButton}
              />
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scroll: {
    flexGrow: 1,
    padding: spacing.lg,
    paddingTop: spacing.xxl + spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  backButton: {
    marginBottom: spacing.md,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: 15,
    color: colors.textSecondary,
  },
  rolesContainer: {
    gap: spacing.md,
  },
  roleCard: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  roleCardSelected: {
    borderColor: colors.sand,
    backgroundColor: colors.sand + '10',
  },
  roleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  roleIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.sand + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  roleIconSelected: {
    backgroundColor: colors.sand,
  },
  roleTextContainer: {
    flex: 1,
  },
  roleLabel: {
    fontSize: 17,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  roleLabelSelected: {
    color: colors.sand,
  },
  roleDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  continueButton: {
    marginTop: spacing.md,
  },
  form: {
    gap: spacing.md,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.divider,
    paddingHorizontal: spacing.md,
  },
  inputIcon: {
    marginRight: spacing.sm,
  },
  input: {
    flex: 1,
    height: 52,
    color: colors.textPrimary,
    fontSize: 16,
  },
  verificationNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: colors.info + '10',
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.info + '30',
  },
  verificationText: {
    flex: 1,
    fontSize: 13,
    color: colors.info,
    lineHeight: 18,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.error + '15',
    padding: spacing.sm + 4,
    borderRadius: borderRadius.sm,
  },
  errorText: {
    color: colors.error,
    fontSize: 13,
    flex: 1,
  },
  signUpButton: {
    marginTop: spacing.sm,
  },
});
