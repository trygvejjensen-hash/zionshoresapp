import React, { useEffect, useState, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GradientBackground } from '../components/GradientBackground';
import { Button } from '../components/Button';
import { useAuth } from '../hooks/useAuth';
import { getUserBookings, cancelBooking } from '../services/bookings';
import { getWave } from '../constants/waves';
import { Booking } from '../types';
import { colors, spacing, borderRadius, shadows } from '../constants/theme';
import { format, parseISO, isPast } from 'date-fns';

export function BookingsScreen({ navigation }: any) {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<'upcoming' | 'past'>('upcoming');

  const loadBookings = useCallback(async () => {
    if (!user) return;
    const result = await getUserBookings(user.id);
    setBookings(result.bookings);
  }, [user]);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadBookings();
    });
    return unsubscribe;
  }, [navigation, loadBookings]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadBookings();
    setRefreshing(false);
  }, [loadBookings]);

  const today = new Date();
  const filtered = bookings.filter((b) => {
    const bookingDate = parseISO(b.date);
    if (filter === 'upcoming') {
      return !isPast(bookingDate) && b.status === 'confirmed';
    }
    return isPast(bookingDate) || b.status !== 'confirmed';
  });

  const formatTime = (time: string) => {
    const [h] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const display = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${display}:00 ${ampm}`;
  };

  async function handleCancel(bookingId: string) {
    Alert.alert('Cancel Booking', 'Are you sure you want to cancel this booking?', [
      { text: 'Keep Booking', style: 'cancel' },
      {
        text: 'Cancel Booking',
        style: 'destructive',
        onPress: async () => {
          const result = await cancelBooking(bookingId);
          if (result.error) {
            Alert.alert('Error', result.error);
          } else {
            loadBookings();
          }
        },
      },
    ]);
  }

  const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
    confirmed: { bg: colors.success + '20', text: colors.success },
    cancelled: { bg: colors.error + '20', text: colors.error },
    completed: { bg: colors.ocean + '20', text: colors.oceanLight },
    no_show: { bg: colors.warning + '20', text: colors.warning },
  };

  return (
    <GradientBackground>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.sand} />
        }
      >
        <Text style={styles.title}>My Bookings</Text>

        {/* Tabs */}
        <View style={styles.tabs}>
          <TouchableOpacity
            style={[styles.tab, filter === 'upcoming' && styles.tabActive]}
            onPress={() => setFilter('upcoming')}
          >
            <Text style={[styles.tabText, filter === 'upcoming' && styles.tabTextActive]}>
              Upcoming
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, filter === 'past' && styles.tabActive]}
            onPress={() => setFilter('past')}
          >
            <Text style={[styles.tabText, filter === 'past' && styles.tabTextActive]}>
              Past
            </Text>
          </TouchableOpacity>
        </View>

        {/* Bookings List */}
        {filtered.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons
              name={filter === 'upcoming' ? 'calendar-outline' : 'time-outline'}
              size={48}
              color={colors.textMuted}
            />
            <Text style={styles.emptyTitle}>
              {filter === 'upcoming' ? 'No Upcoming Bookings' : 'No Past Bookings'}
            </Text>
            <Text style={styles.emptySubtext}>
              {filter === 'upcoming'
                ? 'Book a wave session to get started!'
                : "Your completed sessions will appear here."}
            </Text>
            {filter === 'upcoming' && (
              <Button
                title="Browse Waves"
                onPress={() => navigation.navigate('Home')}
                variant="outline"
                style={styles.emptyButton}
              />
            )}
          </View>
        ) : (
          <View style={styles.bookingsList}>
            {filtered.map((booking) => {
              const wave = getWave(booking.wave_id);
              const statusStyle = STATUS_COLORS[booking.status] || STATUS_COLORS.confirmed;
              return (
                <View key={booking.id} style={styles.bookingCard}>
                  <View style={styles.cardTop}>
                    <View>
                      <Text style={styles.waveName}>{wave?.name || booking.wave_id}</Text>
                      <Text style={styles.bookingDate}>
                        {format(parseISO(booking.date), 'EEEE, MMMM d, yyyy')}
                      </Text>
                      <Text style={styles.bookingTime}>
                        {formatTime(booking.start_time)} – {formatTime(booking.end_time)}
                      </Text>
                    </View>
                    <View>
                      <View
                        style={[styles.statusBadge, { backgroundColor: statusStyle.bg }]}
                      >
                        <Text style={[styles.statusText, { color: statusStyle.text }]}>
                          {booking.status}
                        </Text>
                      </View>
                      <Text style={styles.priceText}>
                        ${(booking.amount_cents / 100).toFixed(0)}
                      </Text>
                    </View>
                  </View>

                  {booking.status === 'confirmed' && !isPast(parseISO(booking.date)) && (
                    <View style={styles.cardActions}>
                      <Button
                        title="Cancel"
                        onPress={() => handleCancel(booking.id)}
                        variant="danger"
                        size="small"
                      />
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        )}

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingTop: spacing.xxl + spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.lg,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    padding: 4,
    marginBottom: spacing.lg,
  },
  tab: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  tabActive: {
    backgroundColor: colors.sand,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textMuted,
  },
  tabTextActive: {
    color: colors.background,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing.xxl * 2,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },
  emptySubtext: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  emptyButton: {
    minWidth: 160,
  },
  bookingsList: {
    gap: spacing.md,
  },
  bookingCard: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.small,
  },
  cardTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  waveName: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  bookingDate: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  bookingTime: {
    fontSize: 13,
    color: colors.textMuted,
  },
  statusBadge: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    alignSelf: 'flex-end',
    marginBottom: spacing.xs,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  priceText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.sand,
    textAlign: 'right',
  },
  cardActions: {
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.divider,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  bottomSpacer: {
    height: spacing.xxl * 2,
  },
});
