import React from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GradientBackground } from '../components/GradientBackground';
import { Button } from '../components/Button';
import { colors, spacing, borderRadius } from '../constants/theme';
import { format, parseISO } from 'date-fns';

export function BookingConfirmationScreen({ route, navigation }: any) {
  const { booking, waveName, price } = route.params;

  const formatTime = (time: string) => {
    const [h] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const display = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${display}:00 ${ampm}`;
  };

  return (
    <GradientBackground>
      <View style={styles.container}>
        {/* Success Icon */}
        <View style={styles.iconContainer}>
          <View style={styles.iconCircle}>
            <Ionicons name="checkmark" size={48} color={colors.background} />
          </View>
        </View>

        <Text style={styles.title}>Booking Confirmed!</Text>
        <Text style={styles.subtitle}>Your wave session has been booked</Text>

        {/* Booking Details Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Ionicons name="water" size={20} color={colors.sand} />
            <Text style={styles.waveName}>{waveName}</Text>
          </View>

          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Ionicons name="calendar-outline" size={18} color={colors.textMuted} />
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>
                {format(parseISO(booking.date), 'EEEE, MMMM d, yyyy')}
              </Text>
            </View>
          </View>

          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Ionicons name="time-outline" size={18} color={colors.textMuted} />
              <Text style={styles.detailLabel}>Time</Text>
              <Text style={styles.detailValue}>
                {formatTime(booking.start_time)} – {formatTime(booking.end_time)}
              </Text>
            </View>
          </View>

          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Ionicons name="card-outline" size={18} color={colors.textMuted} />
              <Text style={styles.detailLabel}>Amount</Text>
              <Text style={styles.detailValue}>{price}</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.bookingIdRow}>
            <Text style={styles.bookingIdLabel}>Booking ID</Text>
            <Text style={styles.bookingIdValue}>{booking.id.slice(0, 8).toUpperCase()}</Text>
          </View>
        </View>

        {/* Tips */}
        <View style={styles.tipsCard}>
          <Text style={styles.tipsTitle}>Session Tips</Text>
          <View style={styles.tipRow}>
            <Ionicons name="time-outline" size={16} color={colors.teal} />
            <Text style={styles.tipText}>Arrive 15 minutes before your session</Text>
          </View>
          <View style={styles.tipRow}>
            <Ionicons name="shirt-outline" size={16} color={colors.teal} />
            <Text style={styles.tipText}>Board & wetsuit rentals available on-site</Text>
          </View>
          <View style={styles.tipRow}>
            <Ionicons name="warning-outline" size={16} color={colors.teal} />
            <Text style={styles.tipText}>No-shows will be charged the full amount</Text>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <Button
            title="View My Bookings"
            onPress={() => navigation.navigate('MainTabs', { screen: 'Bookings' })}
            size="large"
          />
          <Button
            title="Back to Home"
            onPress={() => navigation.navigate('MainTabs', { screen: 'Home' })}
            variant="outline"
            size="large"
          />
        </View>
      </View>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.lg,
    paddingTop: spacing.xxl + spacing.xl,
    alignItems: 'center',
  },
  iconContainer: {
    marginBottom: spacing.lg,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.success,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: 15,
    color: colors.textSecondary,
    marginBottom: spacing.xl,
  },
  card: {
    width: '100%',
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  waveName: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.sand,
  },
  detailRow: {
    marginBottom: spacing.md,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  detailLabel: {
    fontSize: 13,
    color: colors.textMuted,
    minWidth: 50,
  },
  detailValue: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textPrimary,
    flex: 1,
  },
  divider: {
    height: 1,
    backgroundColor: colors.divider,
    marginVertical: spacing.md,
  },
  bookingIdRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookingIdLabel: {
    fontSize: 13,
    color: colors.textMuted,
  },
  bookingIdValue: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textSecondary,
    letterSpacing: 1,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  tipsCard: {
    width: '100%',
    backgroundColor: colors.teal + '10',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.xl,
    borderWidth: 1,
    borderColor: colors.teal + '20',
  },
  tipsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.teal,
    marginBottom: spacing.sm,
  },
  tipRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.xs + 2,
  },
  tipText: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  actions: {
    width: '100%',
    gap: spacing.md,
  },
});
