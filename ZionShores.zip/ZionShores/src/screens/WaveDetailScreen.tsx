import React, { useEffect, useState, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { GradientBackground } from '../components/GradientBackground';
import { SessionSlot } from '../components/SessionSlot';
import { Button } from '../components/Button';
import { useAuth } from '../hooks/useAuth';
import { getWave, getPrice, getBookingWindow, WAVES } from '../constants/waves';
import { getSessionsForDate, canBookDate, getMaxBookingDate, createBooking } from '../services/bookings';
import { getConditionsForWave, getCrowdColor, formatHeight, formatTemp } from '../services/conditions';
import { Session, WaveConditions } from '../types';
import { colors, spacing, borderRadius, shadows, gradients } from '../constants/theme';
import { format, addDays, startOfDay, isSameDay } from 'date-fns';

export function WaveDetailScreen({ route, navigation }: any) {
  const { waveId } = route.params;
  const { user } = useAuth();
  const wave = getWave(waveId);
  const price = user ? getPrice(waveId, user.role) : null;
  const bookingWindow = user ? getBookingWindow(user.role) : null;

  const [selectedDate, setSelectedDate] = useState<Date>(startOfDay(new Date()));
  const [sessions, setSessions] = useState<Session[]>([]);
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const [conditions, setConditions] = useState<WaveConditions | null>(null);
  const [loading, setLoading] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

  const loadSessions = useCallback(async () => {
    if (!wave) return;
    setLoading(true);
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const result = await getSessionsForDate(wave.id, dateStr);
    setSessions(result.sessions);
    setSelectedSession(null);
    setLoading(false);
  }, [wave, selectedDate]);

  useEffect(() => {
    loadSessions();
  }, [loadSessions]);

  useEffect(() => {
    if (!wave) return;
    getConditionsForWave(wave.id).then((r) => setConditions(r.conditions));
  }, [wave]);

  if (!wave || !user) return null;

  const maxDate = getMaxBookingDate(user.role);
  const dates: Date[] = [];
  let d = startOfDay(new Date());
  while (d <= maxDate) {
    dates.push(d);
    d = addDays(d, 1);
  }

  async function handleBooking() {
    if (!selectedSession || !user || !wave || !price) return;

    const canBook = canBookDate(user.role, selectedDate);
    if (!canBook) {
      Alert.alert('Not Available', 'This date is outside your booking window.');
      return;
    }

    if (user.role === 'local' && user.verification_status !== 'approved') {
      Alert.alert(
        'Verification Required',
        'Your local residency verification is still pending. Please wait for admin approval.'
      );
      return;
    }

    setBookingLoading(true);
    const result = await createBooking(
      user.id,
      selectedSession.id,
      wave.id,
      user.role,
      format(selectedDate, 'yyyy-MM-dd'),
      selectedSession.start_time,
      selectedSession.end_time
    );
    setBookingLoading(false);

    if (result.error) {
      Alert.alert('Booking Error', result.error);
      return;
    }

    if (result.booking) {
      navigation.navigate('BookingConfirmation', {
        booking: result.booking,
        waveName: wave.name,
        price: price.label,
      });
    }
  }

  const SKILL_COLORS: Record<string, string> = {
    beginner: colors.beginner,
    intermediate: colors.intermediate,
    advanced: colors.advanced,
  };

  const GRADIENT_MAP: Record<string, string[]> = {
    perfectswell: gradients.perfectswell,
    dynamic: gradients.dynamic,
    standing: gradients.standing,
  };

  return (
    <GradientBackground>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        {/* Hero */}
        <LinearGradient
          colors={GRADIENT_MAP[wave.id] || gradients.card}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroOverlay}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="arrow-back" size={24} color={colors.white} />
            </TouchableOpacity>

            <View style={styles.heroContent}>
              <View
                style={[
                  styles.skillBadge,
                  { backgroundColor: SKILL_COLORS[wave.skill_level] + '30' },
                ]}
              >
                <Text
                  style={[styles.skillText, { color: SKILL_COLORS[wave.skill_level] }]}
                >
                  {wave.skill_level.toUpperCase()}
                </Text>
              </View>
              <Text style={styles.heroTitle}>{wave.name}</Text>
              <Text style={styles.heroSubtitle}>{wave.subtitle}</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Conditions Strip */}
        {conditions && (
          <View style={styles.conditionsStrip}>
            <View style={styles.condItem}>
              <Ionicons name="resize-outline" size={18} color={colors.oceanLight} />
              <Text style={styles.condLabel}>Height</Text>
              <Text style={styles.condValue}>{formatHeight(conditions.current_height_ft)}</Text>
            </View>
            <View style={styles.condDivider} />
            <View style={styles.condItem}>
              <Ionicons name="thermometer-outline" size={18} color={colors.warning} />
              <Text style={styles.condLabel}>Water</Text>
              <Text style={styles.condValue}>{formatTemp(conditions.water_temp_f)}</Text>
            </View>
            <View style={styles.condDivider} />
            <View style={styles.condItem}>
              <Ionicons
                name="people-outline"
                size={18}
                color={getCrowdColor(conditions.crowd_level)}
              />
              <Text style={styles.condLabel}>Crowd</Text>
              <Text
                style={[styles.condValue, { color: getCrowdColor(conditions.crowd_level) }]}
              >
                {conditions.crowd_level}
              </Text>
            </View>
            <View style={styles.condDivider} />
            <View style={styles.condItem}>
              <View
                style={[
                  styles.statusIndicator,
                  {
                    backgroundColor:
                      conditions.status === 'open' ? colors.success : colors.error,
                  },
                ]}
              />
              <Text style={styles.condLabel}>Status</Text>
              <Text style={styles.condValue}>{conditions.status}</Text>
            </View>
          </View>
        )}

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About This Wave</Text>
          <Text style={styles.description}>{wave.description}</Text>
          <View style={styles.specsRow}>
            <View style={styles.specItem}>
              <Text style={styles.specValue}>{wave.width_ft}ft</Text>
              <Text style={styles.specLabel}>Width</Text>
            </View>
            <View style={styles.specItem}>
              <Text style={styles.specValue}>{wave.wave_height_range}</Text>
              <Text style={styles.specLabel}>Wave Range</Text>
            </View>
            <View style={styles.specItem}>
              <Text style={styles.specValue}>{wave.max_capacity}</Text>
              <Text style={styles.specLabel}>Max Surfers</Text>
            </View>
          </View>

          <View style={styles.features}>
            {wave.features.map((f, i) => (
              <View key={i} style={styles.featureRow}>
                <Ionicons name="checkmark-circle" size={16} color={colors.teal} />
                <Text style={styles.featureText}>{f}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Date Picker */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Date</Text>
          {bookingWindow && (
            <Text style={styles.windowHint}>
              You can book up to {bookingWindow.label} ({user.role})
            </Text>
          )}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.dateScroll}
          >
            {dates.map((date) => {
              const isSelected = isSameDay(date, selectedDate);
              const isToday = isSameDay(date, new Date());
              return (
                <TouchableOpacity
                  key={date.toISOString()}
                  style={[styles.dateCard, isSelected && styles.dateCardSelected]}
                  onPress={() => setSelectedDate(date)}
                >
                  <Text
                    style={[styles.dateDow, isSelected && styles.dateTextSelected]}
                  >
                    {isToday ? 'Today' : format(date, 'EEE')}
                  </Text>
                  <Text
                    style={[styles.dateDay, isSelected && styles.dateTextSelected]}
                  >
                    {format(date, 'd')}
                  </Text>
                  <Text
                    style={[styles.dateMonth, isSelected && styles.dateTextSelected]}
                  >
                    {format(date, 'MMM')}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Sessions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Sessions — {format(selectedDate, 'EEEE, MMM d')}
          </Text>
          {loading ? (
            <ActivityIndicator color={colors.sand} style={styles.loader} />
          ) : sessions.length === 0 ? (
            <Text style={styles.noSessions}>No sessions available for this date.</Text>
          ) : (
            sessions.map((session) => (
              <SessionSlot
                key={session.id}
                session={session}
                selected={selectedSession?.id === session.id}
                onPress={() => setSelectedSession(session)}
              />
            ))
          )}
        </View>

        {/* Booking Summary */}
        {selectedSession && price && (
          <View style={styles.bookingSummary}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Wave</Text>
              <Text style={styles.summaryValue}>{wave.name}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Date</Text>
              <Text style={styles.summaryValue}>
                {format(selectedDate, 'EEE, MMM d, yyyy')}
              </Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Time</Text>
              <Text style={styles.summaryValue}>
                {selectedSession.start_time} – {selectedSession.end_time}
              </Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>{price.label}</Text>
            </View>

            <Button
              title={`Book & Pay ${price.label}`}
              onPress={handleBooking}
              loading={bookingLoading}
              size="large"
              style={styles.bookButton}
            />
          </View>
        )}

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {},
  hero: {
    height: 240,
  },
  heroOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 25, 35, 0.5)',
    padding: spacing.lg,
    paddingTop: spacing.xxl + spacing.md,
    justifyContent: 'space-between',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroContent: {},
  skillBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    marginBottom: spacing.sm,
  },
  skillText: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.white,
    marginBottom: 4,
  },
  heroSubtitle: {
    fontSize: 15,
    color: colors.textSecondary,
  },
  conditionsStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    backgroundColor: colors.card,
    marginHorizontal: spacing.md,
    marginTop: -spacing.lg,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.medium,
  },
  condItem: {
    alignItems: 'center',
    gap: 2,
  },
  condLabel: {
    fontSize: 10,
    color: colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  condValue: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  condDivider: {
    width: 1,
    height: 32,
    backgroundColor: colors.divider,
  },
  statusIndicator: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  section: {
    padding: spacing.lg,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.sm,
  },
  description: {
    fontSize: 15,
    color: colors.textSecondary,
    lineHeight: 22,
    marginBottom: spacing.lg,
  },
  specsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  specItem: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    alignItems: 'center',
  },
  specValue: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.sand,
    marginBottom: 2,
  },
  specLabel: {
    fontSize: 11,
    color: colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  features: {
    gap: spacing.sm,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  featureText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  windowHint: {
    fontSize: 13,
    color: colors.textMuted,
    marginBottom: spacing.md,
  },
  dateScroll: {
    gap: spacing.sm,
    paddingVertical: spacing.xs,
  },
  dateCard: {
    width: 64,
    height: 80,
    borderRadius: borderRadius.md,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  dateCardSelected: {
    backgroundColor: colors.sand,
    borderColor: colors.sandLight,
  },
  dateDow: {
    fontSize: 11,
    color: colors.textMuted,
    fontWeight: '500',
    textTransform: 'uppercase',
  },
  dateDay: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  dateMonth: {
    fontSize: 11,
    color: colors.textMuted,
  },
  dateTextSelected: {
    color: colors.background,
  },
  loader: {
    marginVertical: spacing.xl,
  },
  noSessions: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    marginVertical: spacing.xl,
  },
  bookingSummary: {
    marginHorizontal: spacing.lg,
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.medium,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  summaryLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  summaryDivider: {
    height: 1,
    backgroundColor: colors.divider,
    marginVertical: spacing.sm,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  totalValue: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.sand,
  },
  bookButton: {
    marginTop: spacing.md,
  },
  bottomSpacer: {
    height: spacing.xxl * 2,
  },
});
