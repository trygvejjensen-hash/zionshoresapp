import React, { useEffect, useState, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GradientBackground } from '../components/GradientBackground';
import { WaveCard } from '../components/WaveCard';
import { useAuth } from '../hooks/useAuth';
import { WAVES, getBookingWindow } from '../constants/waves';
import { WaveConditions } from '../types';
import { getWaveConditions } from '../services/conditions';
import { getUpcomingBookings } from '../services/bookings';
import { Booking } from '../types';
import { colors, spacing, borderRadius, shadows } from '../constants/theme';
import { getWave } from '../constants/waves';
import { format, parseISO } from 'date-fns';

const { width } = Dimensions.get('window');

export function HomeScreen({ navigation }: any) {
  const { user } = useAuth();
  const [conditions, setConditions] = useState<WaveConditions[]>([]);
  const [upcomingBookings, setUpcomingBookings] = useState<Booking[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    const [condResult, bookingsResult] = await Promise.all([
      getWaveConditions(),
      user ? getUpcomingBookings(user.id) : Promise.resolve({ bookings: [], error: null }),
    ]);
    setConditions(condResult.conditions);
    setUpcomingBookings(bookingsResult.bookings);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, [loadData]);

  const bookingWindow = user ? getBookingWindow(user.role) : null;

  const formatTime = (time: string) => {
    const [h] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const display = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${display}:00 ${ampm}`;
  };

  return (
    <GradientBackground>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.sand}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>
              {getGreeting()}, {user?.full_name?.split(' ')[0] || 'Surfer'}
            </Text>
            <View style={styles.roleRow}>
              <View style={styles.roleBadge}>
                <Text style={styles.roleText}>
                  {user?.role === 'owner'
                    ? 'Property Owner'
                    : user?.role === 'renter'
                    ? 'Property Renter'
                    : 'Local Surfer'}
                </Text>
              </View>
              {bookingWindow && (
                <Text style={styles.windowText}>
                  Book {bookingWindow.label}
                </Text>
              )}
            </View>
          </View>
          <View style={styles.logoSmall}>
            <Ionicons name="water" size={28} color={colors.sand} />
          </View>
        </View>

        {/* Upcoming Booking */}
        {upcomingBookings.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Upcoming Session</Text>
            {upcomingBookings.slice(0, 2).map((booking) => {
              const wave = getWave(booking.wave_id);
              return (
                <View key={booking.id} style={styles.upcomingCard}>
                  <View style={styles.upcomingLeft}>
                    <Text style={styles.upcomingWave}>{wave?.name || booking.wave_id}</Text>
                    <Text style={styles.upcomingTime}>
                      {format(parseISO(booking.date), 'EEE, MMM d')} at{' '}
                      {formatTime(booking.start_time)}
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.upcomingStatus,
                      {
                        backgroundColor:
                          booking.payment_status === 'paid'
                            ? colors.success + '20'
                            : colors.warning + '20',
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.upcomingStatusText,
                        {
                          color:
                            booking.payment_status === 'paid'
                              ? colors.success
                              : colors.warning,
                        },
                      ]}
                    >
                      {booking.payment_status === 'paid' ? 'Confirmed' : 'Pending'}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Verification Warning */}
        {user?.role === 'local' && user.verification_status === 'pending' && (
          <View style={styles.verificationBanner}>
            <Ionicons name="hourglass-outline" size={20} color={colors.warning} />
            <View style={styles.verificationTextContainer}>
              <Text style={styles.verificationTitle}>Verification Pending</Text>
              <Text style={styles.verificationSubtext}>
                Your local resident ID is under review. You can browse waves but booking is
                available after approval.
              </Text>
            </View>
          </View>
        )}

        {/* Waves */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Book a Wave</Text>
          <Text style={styles.sectionSubtitle}>
            Three world-class waves, all skill levels
          </Text>
        </View>

        {WAVES.map((wave) => {
          const waveConditions = conditions.find((c) => c.wave_id === wave.id);
          return (
            <WaveCard
              key={wave.id}
              wave={wave}
              conditions={waveConditions}
              userRole={user?.role}
              onPress={() =>
                navigation.navigate('WaveDetail', { waveId: wave.id })
              }
            />
          );
        })}

        {/* Conditions Summary */}
        <View style={styles.conditionsSummary}>
          <Text style={styles.conditionsTitle}>Current Conditions</Text>
          <View style={styles.conditionsGrid}>
            <View style={styles.conditionCard}>
              <Ionicons name="sunny-outline" size={24} color={colors.warning} />
              <Text style={styles.conditionLabel}>Weather</Text>
              <Text style={styles.conditionVal}>Clear, 95°F</Text>
            </View>
            <View style={styles.conditionCard}>
              <Ionicons name="water-outline" size={24} color={colors.oceanLight} />
              <Text style={styles.conditionLabel}>Water Temp</Text>
              <Text style={styles.conditionVal}>78°F</Text>
            </View>
            <View style={styles.conditionCard}>
              <Ionicons name="time-outline" size={24} color={colors.sand} />
              <Text style={styles.conditionLabel}>Hours</Text>
              <Text style={styles.conditionVal}>7AM–12PM</Text>
            </View>
          </View>
        </View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </GradientBackground>
  );
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingTop: spacing.xxl + spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  greeting: {
    fontSize: 26,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  roleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  roleBadge: {
    backgroundColor: colors.sand + '20',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.sand + '30',
  },
  roleText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.sand,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  windowText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  logoSmall: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.sand + '10',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.sand + '20',
  },
  section: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  upcomingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.sm,
    ...shadows.small,
  },
  upcomingLeft: {},
  upcomingWave: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  upcomingTime: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  upcomingStatus: {
    paddingHorizontal: spacing.sm + 4,
    paddingVertical: spacing.xs + 2,
    borderRadius: borderRadius.full,
  },
  upcomingStatusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  verificationBanner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: colors.warning + '10',
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.warning + '30',
  },
  verificationTextContainer: {
    flex: 1,
  },
  verificationTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.warning,
    marginBottom: 2,
  },
  verificationSubtext: {
    fontSize: 12,
    color: colors.textSecondary,
    lineHeight: 17,
  },
  conditionsSummary: {
    marginHorizontal: spacing.lg,
    marginTop: spacing.md,
  },
  conditionsTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.md,
  },
  conditionsGrid: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  conditionCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    alignItems: 'center',
    gap: spacing.xs,
    ...shadows.small,
  },
  conditionLabel: {
    fontSize: 11,
    color: colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  conditionVal: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  bottomSpacer: {
    height: spacing.xxl,
  },
});
