import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { supabase } from './supabase';
import { UsersPage } from './pages/UsersPage';
import { BookingsPage } from './pages/BookingsPage';
import { WaveConditionsPage } from './pages/WaveConditionsPage';
import { DashboardPage } from './pages/DashboardPage';

const ADMIN_EMAILS = ['admin@zionshores.com']; // Configure your admin emails

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const location = useLocation();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
  }

  if (loading) {
    return (
      <div style={loginStyles.container}>
        <div style={loginStyles.spinner}>Loading...</div>
      </div>
    );
  }

  if (!session) {
    return (
      <div style={loginStyles.container}>
        <div style={loginStyles.card}>
          <div style={loginStyles.logo}>🌊</div>
          <h1 style={loginStyles.title}>Zion Shores Admin</h1>
          <p style={loginStyles.subtitle}>Staff & Management Portal</p>
          <form onSubmit={handleLogin} style={loginStyles.form}>
            <input
              type="email"
              placeholder="Admin email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={loginStyles.input}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={loginStyles.input}
            />
            {error && <p style={loginStyles.error}>{error}</p>}
            <button type="submit" style={loginStyles.button}>Sign In</button>
          </form>
        </div>
      </div>
    );
  }

  const navItems = [
    { path: '/', label: 'Dashboard', icon: '📊' },
    { path: '/users', label: 'Users', icon: '👥' },
    { path: '/bookings', label: 'Bookings', icon: '📅' },
    { path: '/conditions', label: 'Wave Conditions', icon: '🌊' },
  ];

  return (
    <div style={appStyles.container}>
      {/* Sidebar */}
      <nav style={appStyles.sidebar}>
        <div style={appStyles.sidebarHeader}>
          <span style={appStyles.sidebarLogo}>🌊</span>
          <div>
            <div style={appStyles.sidebarTitle}>Zion Shores</div>
            <div style={appStyles.sidebarSubtitle}>Admin Panel</div>
          </div>
        </div>

        <div style={appStyles.navLinks}>
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              style={{
                ...appStyles.navLink,
                ...(location.pathname === item.path ? appStyles.navLinkActive : {}),
              }}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </div>

        <button
          onClick={() => supabase.auth.signOut()}
          style={appStyles.signOutButton}
        >
          Sign Out
        </button>
      </nav>

      {/* Main Content */}
      <main style={appStyles.main}>
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/users" element={<UsersPage />} />
          <Route path="/bookings" element={<BookingsPage />} />
          <Route path="/conditions" element={<WaveConditionsPage />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </div>
  );
}

const loginStyles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'linear-gradient(135deg, #0F1923, #1A2733, #164B60)',
    fontFamily: 'Inter, system-ui, sans-serif',
  },
  card: {
    background: '#1E3044',
    borderRadius: 16,
    padding: 48,
    width: 400,
    textAlign: 'center',
    boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
  },
  logo: { fontSize: 48, marginBottom: 16 },
  title: { color: '#F5F0EB', fontSize: 24, fontWeight: 700, margin: '0 0 4px' },
  subtitle: { color: '#A0B4C8', fontSize: 14, margin: '0 0 32px' },
  form: { display: 'flex', flexDirection: 'column', gap: 12 },
  input: {
    background: '#253D54',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '14px 16px',
    color: '#F5F0EB',
    fontSize: 15,
    outline: 'none',
  },
  error: { color: '#E76F51', fontSize: 13, margin: 0 },
  button: {
    background: 'linear-gradient(90deg, #D4A574, #C4956A)',
    border: 'none',
    borderRadius: 8,
    padding: '14px',
    color: '#0F1923',
    fontSize: 16,
    fontWeight: 700,
    cursor: 'pointer',
    marginTop: 8,
  },
  spinner: { color: '#D4A574', fontSize: 18 },
};

const appStyles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    minHeight: '100vh',
    background: '#0F1923',
    fontFamily: 'Inter, system-ui, sans-serif',
    color: '#F5F0EB',
  },
  sidebar: {
    width: 240,
    background: '#1A2733',
    borderRight: '1px solid rgba(160,180,200,0.1)',
    display: 'flex',
    flexDirection: 'column',
    padding: '24px 16px',
  },
  sidebarHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    marginBottom: 32,
    paddingBottom: 20,
    borderBottom: '1px solid rgba(160,180,200,0.1)',
  },
  sidebarLogo: { fontSize: 32 },
  sidebarTitle: { color: '#F5F0EB', fontWeight: 700, fontSize: 16 },
  sidebarSubtitle: { color: '#6B8299', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 },
  navLinks: { display: 'flex', flexDirection: 'column', gap: 4, flex: 1 },
  navLink: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '10px 12px',
    borderRadius: 8,
    color: '#A0B4C8',
    textDecoration: 'none',
    fontSize: 14,
    fontWeight: 500,
  },
  navLinkActive: {
    background: 'rgba(212,165,116,0.1)',
    color: '#D4A574',
  },
  signOutButton: {
    background: 'rgba(231,111,81,0.1)',
    border: '1px solid rgba(231,111,81,0.3)',
    borderRadius: 8,
    padding: '10px',
    color: '#E76F51',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  main: {
    flex: 1,
    padding: 32,
    overflowY: 'auto',
  },
};
