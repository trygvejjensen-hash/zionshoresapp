import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';

interface Stats {
  totalUsers: number;
  owners: number;
  renters: number;
  locals: number;
  pendingVerifications: number;
  todayBookings: number;
  totalBookings: number;
  revenue: number;
}

export function DashboardPage() {
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0, owners: 0, renters: 0, locals: 0,
    pendingVerifications: 0, todayBookings: 0, totalBookings: 0, revenue: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    const today = new Date().toISOString().split('T')[0];

    const [profiles, pendingRes, todayRes, allBookingsRes] = await Promise.all([
      supabase.from('profiles').select('role'),
      supabase.from('profiles').select('id').eq('verification_status', 'pending'),
      supabase.from('bookings').select('amount_cents').eq('date', today).eq('status', 'confirmed'),
      supabase.from('bookings').select('amount_cents').eq('payment_status', 'paid'),
    ]);

    const users = profiles.data || [];
    setStats({
      totalUsers: users.length,
      owners: users.filter((u: any) => u.role === 'owner').length,
      renters: users.filter((u: any) => u.role === 'renter').length,
      locals: users.filter((u: any) => u.role === 'local').length,
      pendingVerifications: (pendingRes.data || []).length,
      todayBookings: (todayRes.data || []).length,
      totalBookings: (allBookingsRes.data || []).length,
      revenue: (allBookingsRes.data || []).reduce((sum: number, b: any) => sum + (b.amount_cents || 0), 0) / 100,
    });
  }

  const cards = [
    { label: 'Total Users', value: stats.totalUsers, color: '#D4A574', icon: '👥' },
    { label: 'Owners', value: stats.owners, color: '#D4A574', icon: '🏠' },
    { label: 'Renters', value: stats.renters, color: '#4FC0D0', icon: '🔑' },
    { label: 'Locals', value: stats.locals, color: '#2EC4B6', icon: '📍' },
    { label: 'Pending Verifications', value: stats.pendingVerifications, color: '#F4A261', icon: '⏳' },
    { label: "Today's Bookings", value: stats.todayBookings, color: '#87CEEB', icon: '📅' },
    { label: 'Total Bookings', value: stats.totalBookings, color: '#1B6B93', icon: '📊' },
    { label: 'Total Revenue', value: `$${stats.revenue.toLocaleString()}`, color: '#2EC4B6', icon: '💰' },
  ];

  return (
    <div>
      <h1 style={styles.title}>Dashboard</h1>
      <p style={styles.subtitle}>Zion Shores Surf Park Overview</p>

      <div style={styles.grid}>
        {cards.map((card) => (
          <div key={card.label} style={styles.card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={styles.cardLabel}>{card.label}</div>
                <div style={{ ...styles.cardValue, color: card.color }}>
                  {card.value}
                </div>
              </div>
              <span style={{ fontSize: 28 }}>{card.icon}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={styles.section}>
        <h2 style={styles.sectionTitle}>Wave Schedule</h2>
        <div style={styles.scheduleGrid}>
          {[
            { name: 'PerfectSwell Zion', sessions: 5, capacity: 20, color: '#E76F51' },
            { name: 'UNIT Dynamic Wave', sessions: 5, capacity: 16, color: '#F4A261' },
            { name: 'UNIT Standing Wave', sessions: 5, capacity: 12, color: '#2EC4B6' },
          ].map((wave) => (
            <div key={wave.name} style={styles.waveCard}>
              <div style={{ ...styles.waveIndicator, background: wave.color }} />
              <div>
                <div style={styles.waveName}>{wave.name}</div>
                <div style={styles.waveInfo}>
                  {wave.sessions} sessions/day · {wave.capacity} surfers/session · 7AM-12PM
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={styles.section}>
        <h2 style={styles.sectionTitle}>Priority Tiers</h2>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Tier</th>
              <th style={styles.th}>Booking Window</th>
              <th style={styles.th}>PerfectSwell Rate</th>
              <th style={styles.th}>UNIT Waves Rate</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={styles.td}>🏠 Owner (Priority 1)</td>
              <td style={styles.td}>30 days ahead</td>
              <td style={styles.td}>$100/hr</td>
              <td style={styles.td}>$50/hr</td>
            </tr>
            <tr>
              <td style={styles.td}>🔑 Renter (Priority 2)</td>
              <td style={styles.td}>7 days ahead</td>
              <td style={styles.td}>$200/hr</td>
              <td style={styles.td}>$50/hr</td>
            </tr>
            <tr>
              <td style={styles.td}>📍 Local (Priority 3)</td>
              <td style={styles.td}>1 day ahead</td>
              <td style={styles.td}>$200/hr</td>
              <td style={styles.td}>$50/hr</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  title: { fontSize: 28, fontWeight: 700, color: '#F5F0EB', margin: '0 0 4px' },
  subtitle: { color: '#A0B4C8', fontSize: 14, margin: '0 0 24px' },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
    gap: 16,
    marginBottom: 32,
  },
  card: {
    background: '#1E3044',
    borderRadius: 12,
    padding: 20,
    border: '1px solid rgba(160,180,200,0.1)',
  },
  cardLabel: { color: '#6B8299', fontSize: 12, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
  cardValue: { fontSize: 28, fontWeight: 700 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 20, fontWeight: 700, color: '#F5F0EB', margin: '0 0 16px' },
  scheduleGrid: { display: 'flex', flexDirection: 'column', gap: 12 },
  waveCard: {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    background: '#1E3044',
    borderRadius: 12,
    padding: 16,
    border: '1px solid rgba(160,180,200,0.1)',
  },
  waveIndicator: { width: 4, height: 40, borderRadius: 2 },
  waveName: { color: '#F5F0EB', fontWeight: 600, fontSize: 15, marginBottom: 4 },
  waveInfo: { color: '#A0B4C8', fontSize: 13 },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    background: '#1E3044',
    borderRadius: 12,
    overflow: 'hidden',
    border: '1px solid rgba(160,180,200,0.1)',
  },
  th: {
    textAlign: 'left',
    padding: '12px 16px',
    color: '#6B8299',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    borderBottom: '1px solid rgba(160,180,200,0.1)',
    background: '#253D54',
  },
  td: {
    padding: '12px 16px',
    color: '#F5F0EB',
    fontSize: 14,
    borderBottom: '1px solid rgba(160,180,200,0.05)',
  },
};
