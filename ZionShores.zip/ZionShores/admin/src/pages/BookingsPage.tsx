import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';

interface BookingRow {
  id: string;
  user_id: string;
  wave_id: string;
  date: string;
  start_time: string;
  end_time: string;
  amount_cents: number;
  payment_status: string;
  status: string;
  created_at: string;
  profiles?: { full_name: string; email: string; role: string };
}

const WAVE_NAMES: Record<string, string> = {
  perfectswell: 'PerfectSwell Zion',
  dynamic: 'UNIT Dynamic Wave',
  standing: 'UNIT Standing Wave',
};

export function BookingsPage() {
  const [bookings, setBookings] = useState<BookingRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0]);
  const [waveFilter, setWaveFilter] = useState('all');

  useEffect(() => {
    loadBookings();
  }, [dateFilter]);

  async function loadBookings() {
    setLoading(true);
    let query = supabase
      .from('bookings')
      .select('*, profiles(full_name, email, role)')
      .eq('date', dateFilter)
      .order('start_time', { ascending: true });

    const { data } = await query;
    setBookings((data as BookingRow[]) || []);
    setLoading(false);
  }

  const filtered = waveFilter === 'all'
    ? bookings
    : bookings.filter((b) => b.wave_id === waveFilter);

  const STATUS_COLORS: Record<string, string> = {
    confirmed: '#2EC4B6',
    cancelled: '#E76F51',
    completed: '#1B6B93',
    no_show: '#F4A261',
  };

  const PAYMENT_COLORS: Record<string, string> = {
    paid: '#2EC4B6',
    pending: '#F4A261',
    refunded: '#6B8299',
    failed: '#E76F51',
  };

  function formatTime(time: string) {
    const [h] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const display = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${display}:00 ${ampm}`;
  }

  return (
    <div>
      <h1 style={styles.title}>Bookings</h1>
      <p style={styles.subtitle}>
        {filtered.length} bookings for {new Date(dateFilter + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
      </p>

      {/* Filters */}
      <div style={styles.filterRow}>
        <div>
          <label style={styles.label}>Date</label>
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            style={styles.dateInput}
          />
        </div>
        <div>
          <label style={styles.label}>Wave</label>
          <div style={styles.waveFilters}>
            {['all', 'perfectswell', 'dynamic', 'standing'].map((w) => (
              <button
                key={w}
                onClick={() => setWaveFilter(w)}
                style={{
                  ...styles.filterButton,
                  ...(waveFilter === w ? styles.filterActive : {}),
                }}
              >
                {w === 'all' ? 'All Waves' : WAVE_NAMES[w]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bookings Table */}
      {loading ? (
        <p style={{ color: '#A0B4C8' }}>Loading...</p>
      ) : filtered.length === 0 ? (
        <div style={styles.empty}>
          <p style={{ color: '#6B8299', fontSize: 16 }}>No bookings for this date.</p>
        </div>
      ) : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Time</th>
              <th style={styles.th}>Wave</th>
              <th style={styles.th}>Surfer</th>
              <th style={styles.th}>Role</th>
              <th style={styles.th}>Amount</th>
              <th style={styles.th}>Payment</th>
              <th style={styles.th}>Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((booking) => (
              <tr key={booking.id}>
                <td style={styles.td}>
                  {formatTime(booking.start_time)} – {formatTime(booking.end_time)}
                </td>
                <td style={styles.td}>{WAVE_NAMES[booking.wave_id] || booking.wave_id}</td>
                <td style={styles.td}>
                  <div>{booking.profiles?.full_name || '—'}</div>
                  <div style={{ color: '#6B8299', fontSize: 12 }}>
                    {booking.profiles?.email || ''}
                  </div>
                </td>
                <td style={styles.td}>
                  <span style={{ ...styles.badge, background: '#D4A574' + '20', color: '#D4A574' }}>
                    {booking.profiles?.role || '—'}
                  </span>
                </td>
                <td style={{ ...styles.td, fontWeight: 600, color: '#D4A574' }}>
                  ${(booking.amount_cents / 100).toFixed(0)}
                </td>
                <td style={styles.td}>
                  <span
                    style={{
                      ...styles.badge,
                      background: (PAYMENT_COLORS[booking.payment_status] || '#666') + '20',
                      color: PAYMENT_COLORS[booking.payment_status] || '#666',
                    }}
                  >
                    {booking.payment_status}
                  </span>
                </td>
                <td style={styles.td}>
                  <span
                    style={{
                      ...styles.badge,
                      background: (STATUS_COLORS[booking.status] || '#666') + '20',
                      color: STATUS_COLORS[booking.status] || '#666',
                    }}
                  >
                    {booking.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  title: { fontSize: 28, fontWeight: 700, color: '#F5F0EB', margin: '0 0 4px' },
  subtitle: { color: '#A0B4C8', fontSize: 14, margin: '0 0 24px' },
  filterRow: { display: 'flex', gap: 24, marginBottom: 24, alignItems: 'flex-end' },
  label: { display: 'block', color: '#6B8299', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  dateInput: {
    background: '#1E3044',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '10px 14px',
    color: '#F5F0EB',
    fontSize: 14,
    outline: 'none',
    colorScheme: 'dark',
  },
  waveFilters: { display: 'flex', gap: 6 },
  filterButton: {
    background: '#1E3044',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '8px 14px',
    color: '#A0B4C8',
    fontSize: 13,
    fontWeight: 500,
    cursor: 'pointer',
  },
  filterActive: {
    background: 'rgba(212,165,116,0.1)',
    borderColor: '#D4A574',
    color: '#D4A574',
  },
  empty: { textAlign: 'center', padding: 48 },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    background: '#1E3044',
    borderRadius: 12,
    overflow: 'hidden',
    border: '1px solid rgba(160,180,200,0.1)',
  },
  th: {
    textAlign: 'left',
    padding: '12px 16px',
    color: '#6B8299',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    borderBottom: '1px solid rgba(160,180,200,0.1)',
    background: '#253D54',
  },
  td: {
    padding: '12px 16px',
    color: '#F5F0EB',
    fontSize: 14,
    borderBottom: '1px solid rgba(160,180,200,0.05)',
  },
  badge: {
    display: 'inline-block',
    padding: '4px 10px',
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
};
