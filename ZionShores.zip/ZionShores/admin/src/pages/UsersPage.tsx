import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';

interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: string;
  verification_status: string;
  id_document_url: string | null;
  address: string | null;
  zip_code: string | null;
  created_at: string;
}

export function UsersPage() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    setUsers((data as Profile[]) || []);
    setLoading(false);
  }

  async function updateVerification(userId: string, status: 'approved' | 'rejected') {
    await supabase
      .from('profiles')
      .update({ verification_status: status })
      .eq('id', userId);
    loadUsers();
  }

  const filtered = filter === 'all'
    ? users
    : filter === 'pending'
    ? users.filter((u) => u.verification_status === 'pending')
    : users.filter((u) => u.role === filter);

  const ROLE_COLORS: Record<string, string> = {
    owner: '#D4A574',
    renter: '#4FC0D0',
    local: '#2EC4B6',
  };

  const STATUS_COLORS: Record<string, string> = {
    approved: '#2EC4B6',
    pending: '#F4A261',
    rejected: '#E76F51',
  };

  return (
    <div>
      <h1 style={styles.title}>Users</h1>
      <p style={styles.subtitle}>{users.length} total users registered</p>

      {/* Filters */}
      <div style={styles.filters}>
        {['all', 'owner', 'renter', 'local', 'pending'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              ...styles.filterButton,
              ...(filter === f ? styles.filterActive : {}),
            }}
          >
            {f === 'pending' ? '⏳ Pending Verification' : f.charAt(0).toUpperCase() + f.slice(1)}
            {f !== 'all' && f !== 'pending' && (
              <span style={{ ...styles.filterCount, color: ROLE_COLORS[f] }}>
                {users.filter((u) => u.role === f).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Users Table */}
      {loading ? (
        <p style={{ color: '#A0B4C8' }}>Loading...</p>
      ) : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Name</th>
              <th style={styles.th}>Email</th>
              <th style={styles.th}>Role</th>
              <th style={styles.th}>Status</th>
              <th style={styles.th}>ID Document</th>
              <th style={styles.th}>Joined</th>
              <th style={styles.th}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((user) => (
              <tr key={user.id}>
                <td style={styles.td}>{user.full_name}</td>
                <td style={{ ...styles.td, color: '#A0B4C8', fontSize: 13 }}>{user.email}</td>
                <td style={styles.td}>
                  <span
                    style={{
                      ...styles.badge,
                      background: (ROLE_COLORS[user.role] || '#666') + '20',
                      color: ROLE_COLORS[user.role] || '#666',
                    }}
                  >
                    {user.role}
                  </span>
                </td>
                <td style={styles.td}>
                  <span
                    style={{
                      ...styles.badge,
                      background: (STATUS_COLORS[user.verification_status] || '#666') + '20',
                      color: STATUS_COLORS[user.verification_status] || '#666',
                    }}
                  >
                    {user.verification_status}
                  </span>
                </td>
                <td style={styles.td}>
                  {user.id_document_url ? (
                    <a
                      href={user.id_document_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={styles.link}
                    >
                      View ID
                    </a>
                  ) : (
                    <span style={{ color: '#6B8299' }}>—</span>
                  )}
                </td>
                <td style={{ ...styles.td, color: '#6B8299', fontSize: 13 }}>
                  {new Date(user.created_at).toLocaleDateString()}
                </td>
                <td style={styles.td}>
                  {user.verification_status === 'pending' && (
                    <div style={styles.actions}>
                      <button
                        onClick={() => updateVerification(user.id, 'approved')}
                        style={styles.approveButton}
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => updateVerification(user.id, 'rejected')}
                        style={styles.rejectButton}
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  title: { fontSize: 28, fontWeight: 700, color: '#F5F0EB', margin: '0 0 4px' },
  subtitle: { color: '#A0B4C8', fontSize: 14, margin: '0 0 24px' },
  filters: { display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' },
  filterButton: {
    background: '#1E3044',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '8px 16px',
    color: '#A0B4C8',
    fontSize: 13,
    fontWeight: 500,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: 6,
  },
  filterActive: {
    background: 'rgba(212,165,116,0.1)',
    borderColor: '#D4A574',
    color: '#D4A574',
  },
  filterCount: { fontWeight: 700 },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    background: '#1E3044',
    borderRadius: 12,
    overflow: 'hidden',
    border: '1px solid rgba(160,180,200,0.1)',
  },
  th: {
    textAlign: 'left',
    padding: '12px 16px',
    color: '#6B8299',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    borderBottom: '1px solid rgba(160,180,200,0.1)',
    background: '#253D54',
  },
  td: {
    padding: '12px 16px',
    color: '#F5F0EB',
    fontSize: 14,
    borderBottom: '1px solid rgba(160,180,200,0.05)',
  },
  badge: {
    display: 'inline-block',
    padding: '4px 10px',
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  link: { color: '#4FC0D0', textDecoration: 'none', fontSize: 13 },
  actions: { display: 'flex', gap: 6 },
  approveButton: {
    background: 'rgba(46,196,182,0.15)',
    border: '1px solid rgba(46,196,182,0.3)',
    borderRadius: 6,
    padding: '6px 12px',
    color: '#2EC4B6',
    fontSize: 12,
    fontWeight: 600,
    cursor: 'pointer',
  },
  rejectButton: {
    background: 'rgba(231,111,81,0.15)',
    border: '1px solid rgba(231,111,81,0.3)',
    borderRadius: 6,
    padding: '6px 12px',
    color: '#E76F51',
    fontSize: 12,
    fontWeight: 600,
    cursor: 'pointer',
  },
};
