import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';

interface WaveCondition {
  wave_id: string;
  current_height_ft: number;
  water_temp_f: number;
  crowd_level: string;
  status: string;
  updated_at: string;
}

const WAVE_NAMES: Record<string, string> = {
  perfectswell: 'PerfectSwell Zion',
  dynamic: 'UNIT Dynamic Wave',
  standing: 'UNIT Standing Wave',
};

const WAVE_COLORS: Record<string, string> = {
  perfectswell: '#E76F51',
  dynamic: '#F4A261',
  standing: '#2EC4B6',
};

export function WaveConditionsPage() {
  const [conditions, setConditions] = useState<WaveCondition[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    loadConditions();
  }, []);

  async function loadConditions() {
    setLoading(true);
    const { data } = await supabase
      .from('wave_conditions')
      .select('*')
      .order('wave_id');
    setConditions((data as WaveCondition[]) || []);
    setLoading(false);
  }

  async function updateCondition(waveId: string, field: string, value: any) {
    setConditions((prev) =>
      prev.map((c) => (c.wave_id === waveId ? { ...c, [field]: value } : c))
    );
  }

  async function saveCondition(waveId: string) {
    setSaving(waveId);
    const condition = conditions.find((c) => c.wave_id === waveId);
    if (!condition) return;

    await supabase
      .from('wave_conditions')
      .update({
        current_height_ft: condition.current_height_ft,
        water_temp_f: condition.water_temp_f,
        crowd_level: condition.crowd_level,
        status: condition.status,
        updated_at: new Date().toISOString(),
      })
      .eq('wave_id', waveId);

    setSaving(null);
  }

  if (loading) return <p style={{ color: '#A0B4C8' }}>Loading...</p>;

  return (
    <div>
      <h1 style={styles.title}>Wave Conditions</h1>
      <p style={styles.subtitle}>Update real-time conditions for each wave</p>

      <div style={styles.grid}>
        {conditions.map((condition) => (
          <div key={condition.wave_id} style={styles.card}>
            <div style={styles.cardHeader}>
              <div
                style={{
                  ...styles.indicator,
                  background: WAVE_COLORS[condition.wave_id] || '#666',
                }}
              />
              <h3 style={styles.cardTitle}>
                {WAVE_NAMES[condition.wave_id] || condition.wave_id}
              </h3>
            </div>

            <div style={styles.fields}>
              {/* Height */}
              <div style={styles.field}>
                <label style={styles.label}>Wave Height (ft)</label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max="12"
                  value={condition.current_height_ft}
                  onChange={(e) =>
                    updateCondition(condition.wave_id, 'current_height_ft', parseFloat(e.target.value))
                  }
                  style={styles.input}
                />
              </div>

              {/* Water Temp */}
              <div style={styles.field}>
                <label style={styles.label}>Water Temp (°F)</label>
                <input
                  type="number"
                  min="60"
                  max="95"
                  value={condition.water_temp_f}
                  onChange={(e) =>
                    updateCondition(condition.wave_id, 'water_temp_f', parseInt(e.target.value))
                  }
                  style={styles.input}
                />
              </div>

              {/* Crowd Level */}
              <div style={styles.field}>
                <label style={styles.label}>Crowd Level</label>
                <select
                  value={condition.crowd_level}
                  onChange={(e) =>
                    updateCondition(condition.wave_id, 'crowd_level', e.target.value)
                  }
                  style={styles.select}
                >
                  <option value="empty">Empty</option>
                  <option value="light">Light</option>
                  <option value="moderate">Moderate</option>
                  <option value="busy">Busy</option>
                  <option value="full">Full</option>
                </select>
              </div>

              {/* Status */}
              <div style={styles.field}>
                <label style={styles.label}>Status</label>
                <select
                  value={condition.status}
                  onChange={(e) =>
                    updateCondition(condition.wave_id, 'status', e.target.value)
                  }
                  style={styles.select}
                >
                  <option value="open">Open</option>
                  <option value="closed">Closed</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
            </div>

            <div style={styles.cardFooter}>
              <span style={styles.lastUpdated}>
                Last updated: {new Date(condition.updated_at).toLocaleString()}
              </span>
              <button
                onClick={() => saveCondition(condition.wave_id)}
                disabled={saving === condition.wave_id}
                style={styles.saveButton}
              >
                {saving === condition.wave_id ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  title: { fontSize: 28, fontWeight: 700, color: '#F5F0EB', margin: '0 0 4px' },
  subtitle: { color: '#A0B4C8', fontSize: 14, margin: '0 0 24px' },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
    gap: 20,
  },
  card: {
    background: '#1E3044',
    borderRadius: 12,
    padding: 24,
    border: '1px solid rgba(160,180,200,0.1)',
  },
  cardHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
    paddingBottom: 16,
    borderBottom: '1px solid rgba(160,180,200,0.1)',
  },
  indicator: { width: 4, height: 32, borderRadius: 2 },
  cardTitle: { margin: 0, fontSize: 18, fontWeight: 700, color: '#F5F0EB' },
  fields: { display: 'flex', flexDirection: 'column', gap: 16 },
  field: {},
  label: {
    display: 'block',
    color: '#6B8299',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  input: {
    width: '100%',
    background: '#253D54',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '10px 14px',
    color: '#F5F0EB',
    fontSize: 15,
    outline: 'none',
    boxSizing: 'border-box',
  },
  select: {
    width: '100%',
    background: '#253D54',
    border: '1px solid rgba(160,180,200,0.15)',
    borderRadius: 8,
    padding: '10px 14px',
    color: '#F5F0EB',
    fontSize: 15,
    outline: 'none',
    boxSizing: 'border-box',
    appearance: 'none',
  },
  cardFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
    paddingTop: 16,
    borderTop: '1px solid rgba(160,180,200,0.1)',
  },
  lastUpdated: { color: '#6B8299', fontSize: 12 },
  saveButton: {
    background: 'linear-gradient(90deg, #D4A574, #C4956A)',
    border: 'none',
    borderRadius: 8,
    padding: '10px 20px',
    color: '#0F1923',
    fontSize: 13,
    fontWeight: 700,
    cursor: 'pointer',
  },
};
